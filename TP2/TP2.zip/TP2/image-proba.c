/*!
* \file image-proba.c
* \brief File implementing the function to read an image and estimate the probabilities
*/
#include <stdio.h>
#include "image-proba.h"
#include "image.h"

/*! \fn int readProbaFromFile(char* name, float pb[NBVALUES])
* \brief Read the square image made of values between 0 and NBVALUES -1, stored as short int.
* \param[in] name the name of the binary file to be read
* \param[out] pb the probabilities array
* \return int 1 if everything is ok, 0 otherwise
*/
int readProbaFromFile(const char* name, float pb[NBVALUES])
{
    /* to be completed */
  return -1;
}

