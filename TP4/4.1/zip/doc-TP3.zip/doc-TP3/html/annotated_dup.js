var annotated_dup =
[
    [ "ImageRGB", "struct_image_r_g_b.html", "struct_image_r_g_b" ],
    [ "PixelRGB", "struct_pixel_r_g_b.html", "struct_pixel_r_g_b" ]
];