var files_dup =
[
    [ "imageRGB.c", "image_r_g_b_8c.html", "image_r_g_b_8c" ],
    [ "imageRGB.h", "image_r_g_b_8h.html", "image_r_g_b_8h" ]
];