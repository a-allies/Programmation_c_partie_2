var image_r_g_b_8c =
[
    [ "allocateImage", "image_r_g_b_8c.html#a515e33a21b2fe5cceac33b8f2c920e58", null ],
    [ "equalPixel", "image_r_g_b_8c.html#afa870bf21d7cfc00857f698fff7146ba", null ],
    [ "freeImage", "image_r_g_b_8c.html#af063cec6e69a40c04ed1cf5d609780ea", null ],
    [ "getHeight", "image_r_g_b_8c.html#a8b5be4efdc5d7bcb04bed1909f9c3ea7", null ],
    [ "getPixel", "image_r_g_b_8c.html#aa0fce857e33f48ff4a219859ef41180a", null ],
    [ "getWidth", "image_r_g_b_8c.html#a652edcf9e9b7235b41accef6386ffcad", null ],
    [ "setPixel", "image_r_g_b_8c.html#a971ddd467e8bf7526de1a3605fafdf72", null ]
];