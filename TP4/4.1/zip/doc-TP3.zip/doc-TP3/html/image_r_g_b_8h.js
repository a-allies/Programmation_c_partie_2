var image_r_g_b_8h =
[
    [ "PixelRGB", "struct_pixel_r_g_b.html", "struct_pixel_r_g_b" ],
    [ "ImageRGB", "struct_image_r_g_b.html", "struct_image_r_g_b" ],
    [ "MyBoolean", "image_r_g_b_8h.html#a8416e9318ea26998b4816796b48d71a7", [
      [ "MYFALSE", "image_r_g_b_8h.html#a8416e9318ea26998b4816796b48d71a7a2dcc659ed6efcc935e37a5fc7b75df41", null ],
      [ "MYTRUE", "image_r_g_b_8h.html#a8416e9318ea26998b4816796b48d71a7ab95e4e5d1874c3185d900abd761c6858", null ]
    ] ],
    [ "allocateImage", "image_r_g_b_8h.html#a515e33a21b2fe5cceac33b8f2c920e58", null ],
    [ "freeImage", "image_r_g_b_8h.html#a3965b7845490bdfd3e1570c67a276eb6", null ],
    [ "getHeight", "image_r_g_b_8h.html#a8b5be4efdc5d7bcb04bed1909f9c3ea7", null ],
    [ "getPixel", "image_r_g_b_8h.html#aa0fce857e33f48ff4a219859ef41180a", null ],
    [ "getWidth", "image_r_g_b_8h.html#a652edcf9e9b7235b41accef6386ffcad", null ],
    [ "setPixel", "image_r_g_b_8h.html#a971ddd467e8bf7526de1a3605fafdf72", null ]
];