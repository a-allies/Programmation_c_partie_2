var searchData=
[
  ['allocateimage_0',['allocateImage',['../image_r_g_b_8c.html#a515e33a21b2fe5cceac33b8f2c920e58',1,'allocateImage(unsigned int h, unsigned int w):&#160;imageRGB.c'],['../image_r_g_b_8h.html#a515e33a21b2fe5cceac33b8f2c920e58',1,'allocateImage(unsigned int h, unsigned int w):&#160;imageRGB.c']]]
];
