var searchData=
[
  ['equalpixel_2',['equalPixel',['../image_r_g_b_8c.html#afa870bf21d7cfc00857f698fff7146ba',1,'imageRGB.c']]]
];
