var searchData=
[
  ['freeimage_3',['freeImage',['../image_r_g_b_8c.html#af063cec6e69a40c04ed1cf5d609780ea',1,'freeImage(ImageRGB *image):&#160;imageRGB.c'],['../image_r_g_b_8h.html#a3965b7845490bdfd3e1570c67a276eb6',1,'freeImage(ImageRGB *i):&#160;imageRGB.c']]]
];
