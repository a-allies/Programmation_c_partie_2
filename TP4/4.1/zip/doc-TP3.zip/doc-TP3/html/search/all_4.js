var searchData=
[
  ['getheight_4',['getHeight',['../image_r_g_b_8c.html#a8b5be4efdc5d7bcb04bed1909f9c3ea7',1,'getHeight(ImageRGB *image):&#160;imageRGB.c'],['../image_r_g_b_8h.html#a8b5be4efdc5d7bcb04bed1909f9c3ea7',1,'getHeight(ImageRGB *image):&#160;imageRGB.c']]],
  ['getpixel_5',['getPixel',['../image_r_g_b_8c.html#aa0fce857e33f48ff4a219859ef41180a',1,'getPixel(ImageRGB *image, unsigned int r, unsigned int c):&#160;imageRGB.c'],['../image_r_g_b_8h.html#aa0fce857e33f48ff4a219859ef41180a',1,'getPixel(ImageRGB *image, unsigned int r, unsigned int c):&#160;imageRGB.c']]],
  ['getwidth_6',['getWidth',['../image_r_g_b_8c.html#a652edcf9e9b7235b41accef6386ffcad',1,'getWidth(ImageRGB *image):&#160;imageRGB.c'],['../image_r_g_b_8h.html#a652edcf9e9b7235b41accef6386ffcad',1,'getWidth(ImageRGB *image):&#160;imageRGB.c']]],
  ['green_7',['green',['../struct_pixel_r_g_b.html#a244bc64dc81180dd04a6c11311407256',1,'PixelRGB']]]
];
