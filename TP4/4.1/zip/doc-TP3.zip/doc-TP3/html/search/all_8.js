var searchData=
[
  ['pixelrgb_15',['PixelRGB',['../struct_pixel_r_g_b.html',1,'']]]
];
