var searchData=
[
  ['raw_5fdata_16',['raw_data',['../struct_image_r_g_b.html#a1609ef0ce7e3b7978f438df6e21265a2',1,'ImageRGB']]],
  ['red_17',['red',['../struct_pixel_r_g_b.html#a0122321b07bffb16f3a5cdd27922548c',1,'PixelRGB']]]
];
