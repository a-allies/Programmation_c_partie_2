var searchData=
[
  ['imagergb_20',['ImageRGB',['../struct_image_r_g_b.html',1,'']]]
];
