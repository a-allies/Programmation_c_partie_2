var searchData=
[
  ['pixelrgb_21',['PixelRGB',['../struct_pixel_r_g_b.html',1,'']]]
];
