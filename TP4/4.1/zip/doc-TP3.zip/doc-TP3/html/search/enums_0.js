var searchData=
[
  ['myboolean_37',['MyBoolean',['../image_r_g_b_8h.html#a8416e9318ea26998b4816796b48d71a7',1,'imageRGB.h']]]
];
