var searchData=
[
  ['imagergb_2ec_22',['imageRGB.c',['../image_r_g_b_8c.html',1,'']]],
  ['imagergb_2eh_23',['imageRGB.h',['../image_r_g_b_8h.html',1,'']]]
];
