var searchData=
[
  ['setpixel_30',['setPixel',['../image_r_g_b_8c.html#a971ddd467e8bf7526de1a3605fafdf72',1,'setPixel(ImageRGB *image, unsigned int r, unsigned int c, PixelRGB p):&#160;imageRGB.c'],['../image_r_g_b_8h.html#a971ddd467e8bf7526de1a3605fafdf72',1,'setPixel(ImageRGB *image, unsigned int r, unsigned int c, PixelRGB p):&#160;imageRGB.c']]]
];
