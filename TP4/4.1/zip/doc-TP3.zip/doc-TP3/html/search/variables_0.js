var searchData=
[
  ['blue_31',['blue',['../struct_pixel_r_g_b.html#a53125a3aec56167e405e8e5296862ef8',1,'PixelRGB']]]
];
