var searchData=
[
  ['green_32',['green',['../struct_pixel_r_g_b.html#a244bc64dc81180dd04a6c11311407256',1,'PixelRGB']]]
];
