var struct_image_r_g_b =
[
    [ "height", "struct_image_r_g_b.html#ab2e78c61905b4419fcc7b4cfc500fe85", null ],
    [ "raw_data", "struct_image_r_g_b.html#a1609ef0ce7e3b7978f438df6e21265a2", null ],
    [ "width", "struct_image_r_g_b.html#aca34d28e3d8bcbcadb8edb4e3af24f8c", null ]
];