var struct_pixel_r_g_b =
[
    [ "blue", "struct_pixel_r_g_b.html#a53125a3aec56167e405e8e5296862ef8", null ],
    [ "green", "struct_pixel_r_g_b.html#a244bc64dc81180dd04a6c11311407256", null ],
    [ "red", "struct_pixel_r_g_b.html#a0122321b07bffb16f3a5cdd27922548c", null ]
];