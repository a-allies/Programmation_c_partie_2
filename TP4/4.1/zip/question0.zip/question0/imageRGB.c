/*!
 * \file imageRGB .c
 * \brief definition of fonctions associated to the RGB Image structure
 * \author ...
 * \date ...
 */

#include "imageRGB.h"


/*!
 * Allocate an image as a rectangle whose size is specified.
 * \param[in] w image width
 * \param[in] h image height
 * \return a pointer on the new image
 */
ImageRGB *allocateImage( unsigned int h, unsigned int w)
{
    /* to be completed*/
    return NULL;
}

/*!
 * \fn unsigned int getWidth(ImageRGB *image)
 * Returns the width of teh image
 * \param[in] image the image
 * \return unsigned int the image width
 */

unsigned int getWidth(ImageRGB *image)
{
    /* to be completed*/
    return -1;
}

/*!
 * \fn unsigned int getHeight(ImageRGB *image)
 * Returns the height of teh image
 * \param[in] image the image
 * \return unsigned int the image height
 */
unsigned int getHeight(ImageRGB *image)
{
    /* to be completed*/
    return -1;
}

/*!
 *  Free the memore allocated for a structure
 * \param[in] image ImageRGB to be deleted
 */
void  freeImage(ImageRGB * image)
{
    /* to be completed*/
}


/*!
 * \fn void setPixel(ImageRGB *image, unsigned  int r, unsigned  int c , PixelRGB p)
 *  Copy a Pixel at a specified location in the raw data.
 *  c is the column number, r the row number of the Pixel to be set.
 *  Its position in the raw data is given by (c + r*width) since the rows are stored continuously.
 * \param[out] image ImageRGB to be modified
 * \param[in] c The column number of the Pixel to be set
 * \param[in] r The row number of the Pixel to be set
 * \param[in] p Pixel value to set at this location
 */
void setPixel(ImageRGB *image, unsigned int r, unsigned int c , PixelRGB p)
{
    /* to be completed*/
}

/*!
 * \fn PixelRGB getPixel(ImageRGB *image, unsigned int r, unsigned  int c)
 *  Give the pixel value of  specified location in the raw data.
 *  Its position in the raw data is given by (c + r*width) since the rows are stored continuously.
 * \param[in] image ImageRGB to read
 * \param[in] c The column number of the Pixel to read
 * \param[in] r The row number of the Pixel to read
 * \return PixelRGB Pixel value at this location
 */

PixelRGB getPixel(ImageRGB *image, unsigned int r, unsigned int c)
{
    PixelRGB p;
    /* to be completed*/
    return p;
}

/*!
 * \fn ImageRGB* createCross(int length)
 * The resulting image is a red square with a blue cross inside.
 * \param[in] length the square size
 * \return a pointer on the new image
 */

ImageRGB* createCross(int length)
{

    /* to be completed*/
    return NULL;
}

/*!
 * \fn void modifyImage(ImageRGB * image, PixelRGB pix_initial, PixelRGB pix_final)
 *  Modify an image by replacing every pixel with a given value by another one
 * \param[in,out] image ImageRGB to be modified
 * \param[in] pix_initial initial value in the image to be replaced
 * \param[in] pix_final the new value for those pixels
 */
void modifyImage(ImageRGB * image, PixelRGB pix_initial, PixelRGB pix_final)
{
    /* to be completed*/
}


