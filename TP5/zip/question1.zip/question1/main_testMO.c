
#include <stdlib.h>

#include "multimedia-object.h"
int main()
{
   test_MO();
    return 0;
}
