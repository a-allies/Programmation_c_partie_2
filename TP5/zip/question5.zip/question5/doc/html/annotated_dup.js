var annotated_dup =
[
    [ "List", "a00015.html", "a00015" ],
    [ "NodeList", "a00011.html", "a00011" ]
];