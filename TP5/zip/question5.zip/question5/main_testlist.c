
#include <stdlib.h>

#include "listMO.h"
int main()
{
   test_list();
    return 0;
}
