var a00019 =
[
    [ "current", "a00019.html#af030e4b2639a7f7de0ada4ac642c5627", null ],
    [ "sentinel_begin", "a00019.html#ac179ddc93c1d8da9f608c5ec59e93990", null ],
    [ "sentinel_end", "a00019.html#a4f54e5e726af059ca1724f0cc532fad4", null ]
];