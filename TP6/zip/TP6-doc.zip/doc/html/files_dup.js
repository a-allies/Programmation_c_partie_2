var files_dup =
[
    [ "memoryList.c", "a00002.html", "a00002" ],
    [ "memoryList.h", "a00005.html", "a00005" ]
];