var files_dup =
[
    [ "myDoubleTree.c", "a00005.html", "a00005" ],
    [ "myDoubleTree.h", "a00008.html", "a00008" ]
];