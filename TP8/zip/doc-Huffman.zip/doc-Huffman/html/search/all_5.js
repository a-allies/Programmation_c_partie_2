var searchData=
[
  ['getcurrenttree_20',['getCurrentTree',['../list_8c.html#a3bfbe505a0e868e1b5602c4c279ba56d',1,'getCurrentTree(list *l):&#160;list.c'],['../list_8h.html#a1e150fb85b1457b0c246769db8bfe1c4',1,'getCurrentTree(list *l):&#160;list.c']]],
  ['getimagesidelengthfromfile_21',['getImageSideLengthFromFile',['../image_8c.html#ae063e7613698fef7f5ed76e74a095beb',1,'getImageSideLengthFromFile(const char *filename):&#160;image.c'],['../image_8h.html#ae063e7613698fef7f5ed76e74a095beb',1,'getImageSideLengthFromFile(const char *filename):&#160;image.c']]],
  ['getimagesidesize_22',['getImageSideSize',['../image_8c.html#a5fcf530e8a5f0c94f199c2d4284a883f',1,'getImageSideSize(const ImageSquare *im):&#160;image.c'],['../image_8h.html#a5fcf530e8a5f0c94f199c2d4284a883f',1,'getImageSideSize(const ImageSquare *im):&#160;image.c']]],
  ['getpixel_23',['getPixel',['../image_8c.html#ab50fa24ddaa80488b549d47a59ab09b5',1,'getPixel(const ImageSquare *im, unsigned int row, unsigned int col):&#160;image.c'],['../image_8h.html#ab50fa24ddaa80488b549d47a59ab09b5',1,'getPixel(const ImageSquare *im, unsigned int row, unsigned int col):&#160;image.c']]]
];
