var searchData=
[
  ['res1_2etxt_83',['res1.txt',['../res1_8txt.html',1,'']]],
  ['res2_2etxt_84',['res2.txt',['../res2_8txt.html',1,'']]]
];
