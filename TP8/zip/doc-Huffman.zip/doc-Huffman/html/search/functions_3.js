var searchData=
[
  ['empty_97',['empty',['../list_8c.html#a185b7dd5b77fdf2b6315358ac7767e44',1,'empty(list *l):&#160;list.c'],['../list_8h.html#a185b7dd5b77fdf2b6315358ac7767e44',1,'empty(list *l):&#160;list.c']]]
];
