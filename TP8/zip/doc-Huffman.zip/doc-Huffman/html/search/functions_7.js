var searchData=
[
  ['last_107',['last',['../list_8c.html#a86d339159e440962ce42347b99e07625',1,'last(list *l):&#160;list.c'],['../list_8h.html#a86d339159e440962ce42347b99e07625',1,'last(list *l):&#160;list.c']]],
  ['loadimagesquare_108',['loadImageSquare',['../image_8c.html#ac66a58714caf86f7f9f4fcd4bc44d9b3',1,'loadImageSquare(const char *filename):&#160;image.c'],['../image_8h.html#af3710b2dd835a0a8b64e24388d8bde3d',1,'loadImageSquare(const char *filename):&#160;image.c']]]
];
