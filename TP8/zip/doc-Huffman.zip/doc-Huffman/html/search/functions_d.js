var searchData=
[
  ['setonfirst_118',['setOnFirst',['../list_8c.html#aa0ae9a01476366cb08c3e904e2f31433',1,'setOnFirst(list *l):&#160;list.c'],['../list_8h.html#aa0ae9a01476366cb08c3e904e2f31433',1,'setOnFirst(list *l):&#160;list.c']]],
  ['setonlast_119',['setOnLast',['../list_8c.html#ad8a2ca1098f3a37401100bf88c3a4f03',1,'setOnLast(list *l):&#160;list.c'],['../list_8h.html#ad8a2ca1098f3a37401100bf88c3a4f03',1,'setOnLast(list *l):&#160;list.c']]],
  ['setonnext_120',['setOnNext',['../list_8c.html#ad3518ca4cc3bf06f47520e6a17e2b524',1,'list.c']]],
  ['setpixel_121',['setPixel',['../image_8c.html#a7049b7ec9a898f8a9d2fd09aa3f00e2a',1,'setPixel(ImageSquare *im, unsigned int row, unsigned int col, uint16_t pixval):&#160;image.c'],['../image_8h.html#a7049b7ec9a898f8a9d2fd09aa3f00e2a',1,'setPixel(ImageSquare *im, unsigned int row, unsigned int col, uint16_t pixval):&#160;image.c']]]
];
