var indexSectionsWithContent =
{
  0: "bcdefghilmnoprst",
  1: "iln",
  2: "bchilmrt",
  3: "bcdefgilmnoprs",
  4: "cflnprst",
  5: "bn",
  6: "cn"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros"
};

