var searchData=
[
  ['current_122',['current',['../structlist.html#aaf7d81d9ac8b050341f6452f8aeff1fb',1,'list']]]
];
