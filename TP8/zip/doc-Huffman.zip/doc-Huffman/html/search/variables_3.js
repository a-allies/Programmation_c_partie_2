var searchData=
[
  ['next_126',['next',['../structnode_list.html#a5a94c33dcfa6b47a061078f3a6ecf0f3',1,'nodeList']]]
];
