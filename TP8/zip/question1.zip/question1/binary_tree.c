
/*!
* \file binary_tree.c
* \brief File implementing the binary Huffman tree structure as studied in Huffman coding practical work
*/

#include <stdlib.h>
#include <stdio.h>
#include "binary_tree.h"



static void printCode(char cod[CODESIZEMAX], int size_code, float pb)
{
   int i;
   printf("le code dont la proba. est  %5.3f est: ",pb);
   for (i=0;i<size_code;i++) 
   	printf(" %c", cod[i]);
   printf("\n");
}


