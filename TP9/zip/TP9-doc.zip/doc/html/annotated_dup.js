var annotated_dup =
[
    [ "Edge", "struct_edge.html", "struct_edge" ],
    [ "EdgeList", "struct_edge_list.html", "struct_edge_list" ],
    [ "Vertex", "struct_vertex.html", "struct_vertex" ],
    [ "VertexList", "struct_vertex_list.html", "struct_vertex_list" ]
];