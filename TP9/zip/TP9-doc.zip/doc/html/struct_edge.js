var struct_edge =
[
    [ "dist", "struct_edge.html#ab762934f5e368b91128f61b1d9c81db0", null ],
    [ "next_e", "struct_edge.html#a42e963bbfce5a28efa83a4f9be79caf0", null ],
    [ "v", "struct_edge.html#aa5e2bc8875eee62afbab1e3fbad80a3e", null ]
];