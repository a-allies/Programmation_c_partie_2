var struct_edge_list =
[
    [ "current", "struct_edge_list.html#a2039b9c1ab38bd768f9dd060b8986d98", null ],
    [ "first", "struct_edge_list.html#ac05ae89b67dcb5767529db323a4dd33c", null ],
    [ "last", "struct_edge_list.html#a0c5d49cf30748ede3203784f735aced7", null ]
];