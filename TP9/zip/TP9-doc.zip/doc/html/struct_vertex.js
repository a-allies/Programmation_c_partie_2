var struct_vertex =
[
    [ "already_visited", "struct_vertex.html#a65cf68bb1d2ca1903821fbff3449b16c", null ],
    [ "connect", "struct_vertex.html#affc88f6893cfb514a74766500d2600fc", null ],
    [ "dist_to_origin", "struct_vertex.html#a6e8143019afd9f125abbdec38b1a8fdc", null ],
    [ "label", "struct_vertex.html#aee52569b393c4b34161e0a75011f2be4", null ],
    [ "next_v", "struct_vertex.html#abfef425527c2c31b624c161979b226f1", null ],
    [ "path", "struct_vertex.html#ae222f568eb14c53dd413a6e7a50e6e4e", null ]
];