var struct_vertex_list =
[
    [ "current", "struct_vertex_list.html#aa01154c71394b86b096975878b4b402a", null ],
    [ "first", "struct_vertex_list.html#ab1150056a66237a75545ac00ae18551a", null ],
    [ "last", "struct_vertex_list.html#a975e1f43573e477f978994dbe1a83f1e", null ]
];